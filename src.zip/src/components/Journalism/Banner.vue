<template>
  <div class="image_banner">
    <div class="center_banner"></div>

  </div>
</template>
<style scoped>
.image_banner {
  width: 100%;
  height: 320px;
}
.center_banner {
  width: 1366px;
  height: 320px;
  margin: 0 auto;
  background: url("../../assets/images/news/c547db0a-3af1-4e7c-8a14-7d45b600aa3d.jpg")
    center no-repeat;
}
</style>

