<template>
    <footer>
        <div>
            底部
        </div>
    </footer>
</template>
<script>
export default {
    
}
</script>
<style lang="less" scoped>

</style>

