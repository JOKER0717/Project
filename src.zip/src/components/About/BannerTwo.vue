<template>
  <div class="banner_tec">
    <!-- <div class="banner_center"> -->
    <div class="left">
      <h1 class="bj_tec">北京舍南科技有限公司
        <span class="s2">Beijing She Nan Technology Co. Ltd.</span>
      </h1>
      <div class="font_box">
        <p>成立于2003年是中国著名的网络品牌策划、网络品牌形象设计公司</p>
        <p>拥有一支充满智慧、经验与活力的团队，其主要开发人员大多来自著名学府
          经过5年来的执著追求和不懈努力，公司拥有一支由资深设计、技术专家
          优秀的管理、服务人才组成的专业团队， 有着超过6年的互联网应用服务与多媒体应用服务从业经验。
          舍南科技有限公司从事互联网服务的独立品牌。</p>
        <p>为企业提供包括域名注册、虚拟主机、企业邮箱、 网站建设 、手机网站建设、VI设计、网站维护、
          网站推广、电子商务网站开发、企业及行业门户网站建设、企业内部系统建 设全方位互联网解决方案。</p>
      </div>
    </div>
    <div class="right">
      <img src="../../assets/images/about/pic_fg_about1.jpg"
           alt="北京舍南科技有限公司">
    </div>
    <!-- </div> -->
  </div>
</template>
<script>
export default {};
</script>

<style scoped>
.banner_tec {
  height: 440px;
  width: 100%;
  background: white;
  position: relative;
}
.banner_center {
  width: 1366px;
  height: 440px;
  margin: 0 auto;
  /* background: blue; */
}
.banner_tec > .left {
  width: 620px;
  height: 350px;
  float: left;
  margin-top: 66px;
}
.banner_tec > .right {
  width: 560px;
  height: 330px;
  float: right;
  margin: 55px 61px;
}
.bj_tec {
  font-size: 22px;
  padding-top: 50px;
  color: #3b3b3c;
  display: block;
}
.s2 {
  font-size: 14px;
  padding-left: 10px;
}
.font_box {
  width: 550px;
  margin-left: 60px;
  margin-top: 15px;
}
.font_box p {
  text-indent: 32px;
  line-height: 30px;
  color: #59595b;
  text-align: left;
}
</style>

