<template>
  <div class="banner-container">
    <div class="himg_banner">
      <img src="../../assets/images/about/logofff.png"
           class="himg_logo">
      <h1 class="h_detail">量身设计 注重细节</h1>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style  scoped>
.banner-container {
  background: white;
}
.himg_banner {
  height: 360px;
  background: url("../../assets/images/about/banner_about.jpg") center top
    no-repeat;
}
.himg_logo {
  padding-top: 150px;
  display: inline-block;
}
.h_detail {
  font-size: 15px;
  font-weight: 400;
  color: white;
}
</style>


